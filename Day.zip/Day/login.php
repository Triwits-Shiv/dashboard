

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Login</title>
    <link rel="stylesheet" href="style.css">
    
</head>
<body>


<?php
        if (isset($_POST["login"])) {
           $email = $_POST["email"];
           $password = $_POST["password"];
           $conn = mysqli_connect("localhost", "root", "", "users");

           // Check connection
           if($conn === false){
               die("ERROR: Could not connect. "
                   . mysqli_connect_error());
           }
            $sql = "SELECT * FROM users WHERE email = '$email'";
            $result = mysqli_query($conn, $sql);
            $user = mysqli_fetch_array($result, MYSQLI_ASSOC);
            if ($user) {
                if ($password == $user["upassword"]){
                    session_start();
                    $_SESSION["user"] = "yes";
                    header("Location: index.html");
                    die();
                    
                }else{
                    echo '<script>alert("Wrong Password")</script>';
                }
            }else{
                echo '<script>alert("Email not Registered yet")</script>';
            }
        }
        ?>




    <form action="login.php" method="post" id="create-account-form">
        
    <div class="title">
            <h2>LOGIN</h2>
        </div>
        <div class="input-group" >
            <label for="email">Email</label>
            <input type="email" id="email" placeholder="Email" name="email">
            <i class="fas fa-check-circle"></i>
            <i class="fas fa-exclamation-circle"></i>
            <p>Error Message</p>
        </div>
            <div class="input-group">
                <label for="password">Password</label>
                <input type="password" id="password" placeholder="Password"name="password">
                <i class="fas fa-check-circle"></i>
                <i class="fas fa-exclamation-circle"></i>
                <p>Error Message</p>
            </div>
            
        
        <button type="submit" class="btn" name="login">Submit</button>
        
    
    <p>Don't have an account? <a href="http://localhost/day/register.php">Register</a></p>
    <br><br>
    <p>Go to homepage <a href="http://localhost/day/template/index.html
    ">Here</a></p>
    </form>

    
       


    <script src="login.js"></script>




    


    
    
</body>
</html>