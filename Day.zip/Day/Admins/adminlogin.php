

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <link rel="stylesheet" href="style.css">
    
</head>
<body>

<?php
        if (isset($_POST["adminlogin"])) {
           $email = $_POST["email"];
           $password = $_POST["apassword"];
           $conn = mysqli_connect("localhost", "root", "", "users");

           // Check connection
           if($conn === false){
               die("ERROR: Could not connect. "
                   . mysqli_connect_error());
           }
            $sql = "SELECT * FROM admins WHERE email = '$email'";
            $result = mysqli_query($conn, $sql);
            $admin = mysqli_fetch_array($result, MYSQLI_ASSOC);
            if ($admin) {
                if ($password == $admin["password"]){
                    session_start();
                    $_SESSION["admin"] = "yes";
                    header("Location: admin.php");
                    die();
                    
                }else{
                    echo '<script>alert("Password does not match")</script>';
                }
            }else{
                echo '<script>alert("Email not exist")</script>';
            }
        }
        ?>


    <form  action="adminlogin.php" method="post" id="create-account-form">
        
    <div class="title">
            <h2>ADMIN LOGIN</h2>
        </div>
        <div class="input-group" >
            <label for="email">Email</label>
            <input type="email" id="email" placeholder="Email" name="email">
            <i class="fas fa-check-circle"></i>
            <i class="fas fa-exclamation-circle"></i>
            <p>Error Message</p>
        </div>
            <div class="input-group">
                <label for="password">Password</label>
                <input type="password" id="password" placeholder="Password"name="apassword">
                <i class="fas fa-check-circle"></i>
                <i class="fas fa-exclamation-circle"></i>
                <p>Error Message</p>
            </div>
            
        
        <button class="btn" name="adminlogin">Submit</button> 

        <br><br>
        <p>Go to homepage <a href="index.html">Here</a></p>
    
    </form>


   
    
       


    <script>


const form = document.querySelector('#create-account-form');
const emailInput = document.querySelector('#email');
const passwordInput = document.querySelector('#password');






    </script>




    


    
    
</body>
</html>