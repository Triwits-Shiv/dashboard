<html>

<head>
    <title>Insert Page page</title>
</head>

<body>
    
        <?php

        session_start(); 

        // servername => localhost
        // username => root
        // password => empty
        // database name => staff
        $conn = mysqli_connect("localhost", "root", "", "users");

        // Check connection
        if($conn === false){
            die("ERROR: Could not connect. "
                . mysqli_connect_error());
        }

        // Taking all 5 values from the form data(input)
        $uname = $_REQUEST['name'];
        $email = $_REQUEST['email'];
        $upassword = $_REQUEST['password'];
        
        

        $sql = "SELECT * FROM users WHERE email = '$email'";
           $result = mysqli_query($conn, $sql);
           $rowCount = mysqli_num_rows($result);
           if ($rowCount>0) {

            
            
            echo '<script>alert("Email already exist")</script>';

            echo "<script> location.href='register.php'; </script>";
            

           }else{
            $sql = "INSERT INTO users VALUES ('','$uname',
            '$email','$upassword')";

        // Check if the query is successful
        if(mysqli_query($conn, $sql)){
            $message = "Registred Successfuly";
            echo "<h3>data stored in a database successfully."
                . " Please browse your localhost php my admin"
                . " to view the updated data</h3>";


                
                
                echo "<script> location.href='template/index.html'; </script>";

                echo "<script>alert(`Registered Successfully `$uname)</script>";


            
        } else{
            echo "ERROR: Hush! Sorry $sql. "
                . mysqli_error($conn);
        }
           }

        // We are going to insert the data into our sampleDB table
       
        

        // Close connection
        mysqli_close($conn);
        ?>
    
</body>

</html>