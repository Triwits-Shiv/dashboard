<?php
$conn = mysqli_connect("localhost", "root", "", "owner");

// Check connection
if($conn === false){
    die("ERROR: Could not connect. "
        . mysqli_connect_error());
}

$id = $_GET["sid"];

$sql = "DELETE FROM `superadmin` WHERE `sid`= $id";
$result = mysqli_query($conn, $sql);

if ($result) {
  
  
  header("Location:http://localhost/owner/template/table.php");
  
  echo "<script>alert(`Deleated Successfully`)</script>";
  
} else {
  echo "Failed: " . mysqli_error($conn);
}